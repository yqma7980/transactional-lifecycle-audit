# Supplementary Software S1

This package contains the standalone benchmark code required by the article. It excludes the private Abaqus/UEL production project and unpublished application outputs.

## Current supported environment

The open finite-element and mutation benchmarks use Python 3.12 with the versions pinned in `requirements-feh-mut.txt`. Run them in an isolated environment. The historical material under `legacy_release_reference/` is retained only to document earlier development and is not a second supported execution stack.

## Minimal smoke test

The command below runs one analytical patch case. It verifies installation and the current public runner; it is not a reproduction of the complete evidence matrix.

```powershell
python -m venv .venv-feh
.\.venv-feh\Scripts\python.exe -m pip install -r requirements-feh-mut.txt
$env:OMP_NUM_THREADS = '1'
$env:OPENBLAS_NUM_THREADS = '1'
$env:MKL_NUM_THREADS = '1'
$env:NUMEXPR_NUM_THREADS = '1'
$env:FEH_D0_EXECUTION_AUTHORIZED = 'YES'
.\.venv-feh\Scripts\python.exe benchmarks/FEH_D0/run_feh_d0.py --case-id FEH-REF-01 --run-id smoke_1 --output-root reproduction_outputs --execute-authorized
```

The runner writes only to the selected `reproduction_outputs` directory. Compare the generated `case_result.json` and manifest against the corresponding schema and evidence locator in Supplementary Data S1. Full-matrix execution requires the individual frozen case matrices and authorization gates; no single-case smoke test is represented as a complete reproduction.

## Evidence and licensing boundary

The package does not invoke Abaqus or reproduce the private doctoral production model. Code licensing and the permanent release identifier must match the archived release cited by the final article. Numerical data licensing is declared separately in Supplementary Data S1.
